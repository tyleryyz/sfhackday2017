var require = meteorInstall({"imports":{"api":{"cameras":{"server":{"publications.js":["meteor/meteor","../cameras.js",function(require,exports,module){

///////////////////////////////////////////////////////////////////////
//                                                                   //
// imports/api/cameras/server/publications.js                        //
//                                                                   //
///////////////////////////////////////////////////////////////////////
                                                                     //
var Meteor;module.import('meteor/meteor',{"Meteor":function(v){Meteor=v}});var Camera;module.import('../cameras.js',{"Camera":function(v){Camera=v}});
                                                                     //
                                                                     // 3
                                                                     //
Meteor.publish('myCameras', function (thisuserid) {                  // 7
  return Camera.find({ userID: thisuserid });                        // 8
});                                                                  // 9
///////////////////////////////////////////////////////////////////////

}]},"cameras.js":["meteor/mongo","meteor/meteor","meteor/aldeed:simple-schema",function(require,exports,module){

///////////////////////////////////////////////////////////////////////
//                                                                   //
// imports/api/cameras/cameras.js                                    //
//                                                                   //
///////////////////////////////////////////////////////////////////////
                                                                     //
module.export({Camera:function(){return Camera}});var Mongo;module.import('meteor/mongo',{"Mongo":function(v){Mongo=v}});var Meteor;module.import('meteor/meteor',{"Meteor":function(v){Meteor=v}});var SimpleSchema;module.import('meteor/aldeed:simple-schema',{"SimpleSchema":function(v){SimpleSchema=v}});
                                                                     // 2
                                                                     // 3
                                                                     //
SimpleSchema.debug = true;                                           // 5
                                                                     //
var Camera = new Mongo.Collection('camera');                         // 7
                                                                     //
Camera.allow({                                                       // 9
  insert: function () {                                              // 10
    function insert() {                                              // 10
      return true;                                                   // 10
    }                                                                // 10
                                                                     //
    return insert;                                                   // 10
  }(),                                                               // 10
  update: function () {                                              // 11
    function update() {                                              // 11
      return true;                                                   // 11
    }                                                                // 11
                                                                     //
    return update;                                                   // 11
  }(),                                                               // 11
  remove: function () {                                              // 12
    function remove() {                                              // 12
      return true;                                                   // 12
    }                                                                // 12
                                                                     //
    return remove;                                                   // 12
  }()                                                                // 12
});                                                                  // 9
                                                                     //
Camera.schema = new SimpleSchema({                                   // 15
  url: {                                                             // 16
    type: String,                                                    // 17
    optional: false                                                  // 18
  },                                                                 // 16
  title: {                                                           // 20
    type: String,                                                    // 21
    optional: false                                                  // 22
  },                                                                 // 20
  categories: {                                                      // 24
    type: String,                                                    // 25
    optional: true                                                   // 26
  },                                                                 // 24
  favorite: {                                                        // 28
    type: Boolean,                                                   // 29
    optional: false,                                                 // 30
    defaultValue: false                                              // 31
  },                                                                 // 28
  userID: {                                                          // 33
    type: String,                                                    // 34
    optional: false,                                                 // 35
    autoValue: function () {                                         // 36
      function autoValue() {                                         // 36
        return this.userId;                                          // 37
      }                                                              // 38
                                                                     //
      return autoValue;                                              // 36
    }()                                                              // 36
  }                                                                  // 33
});                                                                  // 15
                                                                     //
Camera.attachSchema(Camera.schema);                                  // 42
///////////////////////////////////////////////////////////////////////

}]},"saved_cameras":{"server":{"publications.js":["meteor/meteor","../saved_cameras.js",function(require,exports,module){

///////////////////////////////////////////////////////////////////////
//                                                                   //
// imports/api/saved_cameras/server/publications.js                  //
//                                                                   //
///////////////////////////////////////////////////////////////////////
                                                                     //
var Meteor;module.import('meteor/meteor',{"Meteor":function(v){Meteor=v}});var Saved_camera;module.import('../saved_cameras.js',{"Saved_camera":function(v){Saved_camera=v}});
                                                                     // 2
                                                                     //
Meteor.publish('mySavedCameras', function (thisuserid) {             // 4
  return Saved_camera.find({ userID: thisuserid });                  // 5
});                                                                  // 6
///////////////////////////////////////////////////////////////////////

}]},"saved_cameras.js":["meteor/mongo","meteor/meteor","meteor/aldeed:simple-schema",function(require,exports,module){

///////////////////////////////////////////////////////////////////////
//                                                                   //
// imports/api/saved_cameras/saved_cameras.js                        //
//                                                                   //
///////////////////////////////////////////////////////////////////////
                                                                     //
module.export({Saved_camera:function(){return Saved_camera}});var Mongo;module.import('meteor/mongo',{"Mongo":function(v){Mongo=v}});var Meteor;module.import('meteor/meteor',{"Meteor":function(v){Meteor=v}});var SimpleSchema;module.import('meteor/aldeed:simple-schema',{"SimpleSchema":function(v){SimpleSchema=v}});
                                                                     // 2
                                                                     // 3
                                                                     //
SimpleSchema.debug = true;                                           // 5
                                                                     //
var Saved_camera = new Mongo.Collection('saved_camera');             // 7
                                                                     //
Saved_camera.allow({                                                 // 9
  insert: function () {                                              // 10
    function insert() {                                              // 10
      return true;                                                   // 10
    }                                                                // 10
                                                                     //
    return insert;                                                   // 10
  }(),                                                               // 10
  update: function () {                                              // 11
    function update() {                                              // 11
      return true;                                                   // 11
    }                                                                // 11
                                                                     //
    return update;                                                   // 11
  }(),                                                               // 11
  remove: function () {                                              // 12
    function remove() {                                              // 12
      return true;                                                   // 12
    }                                                                // 12
                                                                     //
    return remove;                                                   // 12
  }()                                                                // 12
});                                                                  // 9
                                                                     //
Saved_camera.schema = new SimpleSchema({                             // 15
  url: {                                                             // 16
    type: String,                                                    // 17
    optional: false                                                  // 18
  },                                                                 // 16
  title: {                                                           // 20
    type: String,                                                    // 21
    optional: false                                                  // 22
  },                                                                 // 20
  timestamp: {                                                       // 24
    type: Date,                                                      // 25
    optional: false                                                  // 26
  },                                                                 // 24
  categories: {                                                      // 28
    type: String,                                                    // 29
    optional: true                                                   // 30
  },                                                                 // 28
  video: {                                                           // 32
    type: Boolean,                                                   // 33
    optional: false,                                                 // 34
    defaultValue: false                                              // 35
  },                                                                 // 32
  image: {                                                           // 37
    type: Boolean,                                                   // 38
    optional: false,                                                 // 39
    defaultValue: false                                              // 40
  },                                                                 // 37
  favorite: {                                                        // 42
    type: Boolean,                                                   // 43
    optional: false,                                                 // 44
    defaultValue: false                                              // 45
  },                                                                 // 42
  userID: {                                                          // 47
    type: String,                                                    // 48
    optional: false,                                                 // 49
    autoValue: function () {                                         // 50
      function autoValue() {                                         // 50
        return this.userId;                                          // 51
      }                                                              // 52
                                                                     //
      return autoValue;                                              // 50
    }()                                                              // 50
  }                                                                  // 47
});                                                                  // 15
                                                                     //
Saved_camera.attachSchema(Saved_camera.schema);                      // 56
///////////////////////////////////////////////////////////////////////

}]}},"startup":{"server":{"index.js":["./register-apis.js",function(require,exports,module){

///////////////////////////////////////////////////////////////////////
//                                                                   //
// imports/startup/server/index.js                                   //
//                                                                   //
///////////////////////////////////////////////////////////////////////
                                                                     //
module.import("./register-apis.js");                                 // 1
///////////////////////////////////////////////////////////////////////

}],"register-apis.js":["../../api/cameras/server/publications.js","../../api/saved_cameras/server/publications.js",function(require,exports,module){

///////////////////////////////////////////////////////////////////////
//                                                                   //
// imports/startup/server/register-apis.js                           //
//                                                                   //
///////////////////////////////////////////////////////////////////////
                                                                     //
module.import("../../api/cameras/server/publications.js");module.import("../../api/saved_cameras/server/publications.js");
                                                                     // 2
///////////////////////////////////////////////////////////////////////

}]}}},"server":{"main.js":["/imports/startup/server",function(require,exports,module){

///////////////////////////////////////////////////////////////////////
//                                                                   //
// server/main.js                                                    //
//                                                                   //
///////////////////////////////////////////////////////////////////////
                                                                     //
module.import('/imports/startup/server');                            // 1
///////////////////////////////////////////////////////////////////////

}]}},{"extensions":[".js",".json"]});
require("./server/main.js");
//# sourceMappingURL=app.js.map
